import React from "react";
import AllBlogs from "./AllBlogs";
import Pagination from "./Pagination";

const index = () => {
  return (
    <div>
      <AllBlogs />
      <Pagination />
    </div>
  );
};

export default index;

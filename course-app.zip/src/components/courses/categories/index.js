import React from "react";
import CourseIntro from "./CourseIntro";
import CourseLists from "./CourseLists";

const index = () => {
  return (
    <div>
      <CourseIntro />
      <CourseLists />
    </div>
  );
};

export default index;

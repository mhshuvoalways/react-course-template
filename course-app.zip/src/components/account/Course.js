import React from "react";

const Course = () => {
  return (
    <div className="w-full md:w-6/12 m-auto p-10">
        <p className="text-3xl text-center md:text-left md:text-7xl">Comming soon</p>
    </div>
  );
};

export default Course;
